import { View, Text } from 'react-native'
import React from 'react'

export default function SignInPage() {
  return (
    <View>
      <Text>SignInPage</Text>
    </View>
  )
}